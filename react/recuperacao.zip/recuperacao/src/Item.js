import React from 'react';

function Item(props) {
  return (
    <li>{props.nome}</li>
  );
}

export default Item;