'use strict';
export function formatDatetime(date, showDate = true, showTime = true) {
  let resposta = "";
  if(showDate) {
    let dia = date.getDate();
    dia = dia < 10 ? "0"+(dia):dia;
    let mes = date.getMonth();
    mes = mes < 9 ? "0"+(mes+1):mes;
    let ano = date.getFullYear();
    resposta  += dia+"/"+mes+"/"+ano;
  } if (showTime) {
    let hora = date.getHours();
    hora = hora < 10 ? "0"+hora:hora;
    let minuto = date.getMinutes();
    minuto = minuto < 10 ? "0"+minuto:minuto;
    let segundo = date.getSeconds();
    segundo = segundo < 10 ? "0"+segundo:segundo;
    if (showDate) {
      resposta  += " "+hora+":"+minuto+":"+segundo;
    }else {
      resposta  += hora+":"+minuto+":"+segundo;
    }
  }
  if(!showDate && !showTime) {
    throw new Error("Exibição inválida");
  }
  return resposta ;
}
