'use strict';
export function normalize(palavra) {
  let resposta = palavra.normalize('NFD');
  resposta = resposta.replace(/[\u0300-\u036f]/g,"");
  return resposta;
}
