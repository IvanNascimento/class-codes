'use strict';
export function toObject(csv, ...names) {
  let objeto = {}
  csv = csv.split(",");
  for(let i in names) {
    objeto[names[i]] = csv[i];
  }
  return objeto;
}
