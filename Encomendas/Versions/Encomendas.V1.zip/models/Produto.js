module.exports = function(sequelize , DataTypes){
  
  var Produto = sequelize.defene('Produto', {
    Nome: {type: DataTypes.STRING, allowNull: false},
    CodigoBarra: {type: DataTypes.STRING, allowNull: false},
    Valor: {type: DataTypes.REAl, allowNull: false},
    CodigoRastreio: {type: DataTypes.STRING, allowNull: false}
  });
  
  Produto.associate = function(models){
    Produto.belongsTo(models.Encomenda);
  };
  
  return Produto;
  
};