$(document).ready(function() {
	// do something here
});